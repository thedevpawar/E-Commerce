"""
check_setup.py
Task 1: Validate that the Python environment is set up correctly.

Imports every required library, prints its version, and runs a tiny
scikit-learn model to confirm everything works end to end.

Usage:
    python src/check_setup.py
"""

import sys
import importlib

REQUIRED = ["numpy", "pandas", "sklearn", "matplotlib", "seaborn", "ucimlrepo"]


def check_imports():
    """Try importing each required package and report its version."""
    all_ok = True
    print(f"Python version: {sys.version.split()[0]}\n")
    for name in REQUIRED:
        try:
            module = importlib.import_module(name)
            version = getattr(module, "__version__", "unknown")
            print(f"  [OK]      {name:<12} {version}")
        except ImportError:
            print(f"  [MISSING] {name}")
            all_ok = False
    return all_ok


def run_sample_model():
    """Train a tiny classifier on synthetic data as a smoke test."""
    from sklearn.datasets import make_classification
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split

    X, y = make_classification(n_samples=500, n_features=10, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = LogisticRegression(max_iter=1000).fit(X_train, y_train)
    print(f"\nSample model test accuracy: {model.score(X_test, y_test):.3f}")


if __name__ == "__main__":
    print("Checking environment...\n")
    if check_imports():
        run_sample_model()
        print("\nSetup validated successfully.")
    else:
        print("\nSome packages are missing. Run: pip install -r requirements.txt")
        sys.exit(1)
