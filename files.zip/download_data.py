"""
download_data.py
Downloads the PhiUSIIL Phishing URL Dataset from the UCI ML Repository
and saves it to data/phiusiil_phishing.csv.

Dataset citation:
    Prasad, A., & Chandra, S. (2023). PhiUSIIL: A diverse security profile
    empowered phishing URL detection framework based on similarity index
    and incremental learning. Computers & Security, 103545.
    https://doi.org/10.1016/j.cose.2023.103545
    Licence: CC BY 4.0

Usage:
    python src/download_data.py
"""

from pathlib import Path

import pandas as pd
from ucimlrepo import fetch_ucirepo

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
OUTPUT_FILE = DATA_DIR / "phiusiil_phishing.csv"


def main():
    if OUTPUT_FILE.exists():
        print(f"Dataset already exists at {OUTPUT_FILE}")
        return

    print("Downloading PhiUSIIL dataset from UCI (id=967)...")
    dataset = fetch_ucirepo(id=967)

    # Combine features and target into a single table
    df = pd.concat([dataset.data.features, dataset.data.targets], axis=1)

    DATA_DIR.mkdir(exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)
    print(f"Saved {len(df):,} rows and {df.shape[1]} columns to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
