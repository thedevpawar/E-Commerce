# AI-Driven Cyber Threat Awareness and Detection Prototype

**Course:** AI in Cyber Security Lab (ENSP355), K.R. Mangalam University
**Assignment:** Lab Assignment 01, Unit 1 Mini Project
**Author:** <Your Name>

A prototype that analyses phishing website data, then detects phishing URLs
using classic machine learning (Logistic Regression, Decision Tree) and a
simple neural network (MLPClassifier), followed by an ethical analysis of
false positives, bias, privacy and explainability.

## Dataset

**PhiUSIIL Phishing URL Dataset** (2023–24): 235,795 URLs
(134,850 legitimate, 100,945 phishing) with 54 features extracted from
each URL and its webpage source code.

- Source: [UCI ML Repository](https://archive.ics.uci.edu/dataset/967/phiusiil+phishing+url+dataset)
- Licence: CC BY 4.0
- Citation: Prasad, A., & Chandra, S. (2023). PhiUSIIL: A diverse security
  profile empowered phishing URL detection framework based on similarity
  index and incremental learning. *Computers & Security*, 103545.
  https://doi.org/10.1016/j.cose.2023.103545

The CSV is not committed to the repo (it is ~55 MB). Download it with the
script below.

## Project Structure

```
├── data/                 # Dataset (downloaded, git-ignored)
├── reports/figures/      # Exported plots
├── src/
│   ├── check_setup.py    # Task 1: environment validation
│   └── download_data.py  # Downloads the dataset
├── requirements.txt
└── README.md
```

## Setup

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd ai-cybersecurity-unit1-mini-project-<yourname>

# 2. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux

# 3. Install dependencies
pip install -r requirements.txt

# 4. Validate the setup
python src/check_setup.py

# 5. Download the dataset
python src/download_data.py
```

## Usage

_To be completed as tasks are added._

## Results

_To be completed._
